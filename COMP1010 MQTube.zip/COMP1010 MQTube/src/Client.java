package src;

public class Client {
    public static void main(String[] args) {
        MQTubeManager manager = new MQTubeManager();
        manager.run();
    }
}
